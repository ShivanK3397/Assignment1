import java.util.Scanner;
public class Q4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("How old are you? ");
        int age = scanner.nextInt();
        if (age < 18){
            System.out.println("You will be able to vote in " + (18-age)+ " years");
        }
        else{
            System.out.println("You are old enough to vote");
        }
        scanner.close();
    }

}
