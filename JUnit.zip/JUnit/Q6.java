import java.util.Scanner;
public class Q6 {
    public static void selectionsort(double[] values){
        int i, j, argMax;
        for (i = 0; i < values.length - 1; i++){
            argMax = i;
            for (j = i + 1; j < values.length; j ++){
                if (values[j]> values[argMax]){
                    argMax = j;
                }

            }
            double tmp = values[argMax];
            values[argMax] = values[i];
            values[i] = tmp;
        }
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double[] grades = new double[10];
        int i = 0;
        while (i<10) {
            System.out.println("Enter a grade: ");
            grades[i] = scanner.nextDouble();
            i++;
        }
        scanner.close();
        System.out.println("average "+calculateAverage(grades));
        System.out.println("median "+calculateMedian(grades));
        System.out.println("Fails "+calculateNumberFailed(grades));
        System.out.println("passed "+calculateNumberPassed(grades));
    }
    public static double calculateAverage(double[] notes){
        double sum = 0.0;
        for (double note: notes){
            sum += note;
        }
        double avg = sum/notes.length;
        return avg;

    }
    public static double calculateMedian(double[] notes){
        selectionsort(notes);
        if (notes.length % 2 == 0){
		    return (notes[notes.length/2 - 1] + notes[notes.length/2])/2.0;
        }
        else{
            return ( notes[(notes.length + 1)/2]);
        }
	}
    public static int calculateNumberFailed(double[] notes){
		int fails = 0;
        for (double i: notes){
            if (i < 50){
                fails += 1;
            }
        }
        return fails;
	}
    public static int calculateNumberPassed(double[] notes){
		int fails = calculateNumberFailed(notes);
        int passes = notes.length - fails;
        return passes;
	}
}
