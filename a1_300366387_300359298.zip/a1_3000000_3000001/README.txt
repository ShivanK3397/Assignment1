Student Names: Shivan Kathir and Bruce Wang
Student Number: 300366387 300359298
Section: A

This folder contains a java program that simulates a parkinglot that can read input data of a lot design and cars to park and create a memory representation of the lot design with the cars parked. 